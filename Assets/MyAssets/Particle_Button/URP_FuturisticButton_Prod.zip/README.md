# Futuristic Button Package (URP)
1. Import this `Assets/` folder into your Unity project.
2. Ensure URP is active and Bloom is enabled in your post-processing volume.
3. Drag `FuturisticLaunchButton.prefab` into a Canvas.
4. Drag `DustEmitter.prefab` into the scene (off-screen).
5. On play, dust particles will converge into the button, revealing a glowing neon button.
